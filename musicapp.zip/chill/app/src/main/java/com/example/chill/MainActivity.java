package com.example.chill;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import android.widget.Button;
import android.content.Intent;
import android.view.View;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    public Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView username = (TextView) findViewById(R.id.username);
        TextView password_toggle = (TextView) findViewById(R.id.password_toggle);
        MaterialButton loginbtn = (MaterialButton) findViewById(R.id.login);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                if (username.getText().toString().equals("admin") && password_toggle.getText().toString().equals("admin")) {
                    Toast.makeText(MainActivity.this, "login successfull", Toast.LENGTH_SHORT).show();
                    button=(Button)findViewById(R.id.login);
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent=new Intent(MainActivity.this,homepage.class);
                            startActivity(intent);
                        }
                    });
                }
                else
                    Toast.makeText(MainActivity.this, "login failed", Toast.LENGTH_SHORT).show();








            }
        });

    }
}