package com.example.chill;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class artist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist);
    }
}