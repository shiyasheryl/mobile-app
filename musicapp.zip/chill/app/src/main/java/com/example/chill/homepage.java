package com.example.chill;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.Toast;
import android.view.View;



public class homepage extends AppCompatActivity {
    private Button button1;
    private Button button2;
    private Button button4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        button1 = findViewById(R.id.trending);
        button2 = findViewById(R.id.playlist);
        button4 = findViewById(R.id.podcast);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(homepage.this,trending .class);
                startActivity(intent);


            }


        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(homepage.this, playlist.class);
                startActivity(intent);


            }


        });




        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(homepage.this, podcast.class);
                startActivity(intent);


            }


        });
    }}