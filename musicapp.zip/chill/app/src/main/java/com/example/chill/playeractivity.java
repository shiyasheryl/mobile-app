package com.example.chill;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class playeractivity extends AppCompatActivity {
    Button btnplay,btnNext,btnprev,btnpause;
    TextView txtSongName,txtSongStart,txtSongEnd;
    SeekBar seekMusicbar;
    ImageView imageView;
    String songName;
    public static final String EXTRA_NAME ="song_name";
    static MediaPlayer mediaPlayer;
    int position;
    ArrayList<File> mysongs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playeractivity);

        //btnplay=findViewById(R.id.play);
        btnprev=findViewById(R.id.previous);
        btnNext=findViewById(R.id.next);
        btnpause=findViewById(R.id.pause);



        seekMusicbar=findViewById(R.id.seekbar);
        txtSongName=findViewById(R.id.txtsong);
        txtSongStart=findViewById(R.id.txtsongstart);
        txtSongEnd=findViewById(R.id.txtsongend);
        imageView=findViewById(R.id.imgview);

        if(mediaPlayer !=null)
        {
            mediaPlayer.start();
            mediaPlayer.release();
        }

        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
        mysongs=(ArrayList)bundle.getParcelableArrayList("songs");
        String sName  =intent.getStringExtra("songsName");
        position= bundle.getInt("pos",0);
        txtSongName.setSelected(true);
        Uri uri = Uri.parse(mysongs.get(position).toString());
        songName=mysongs.get(position).getName();
        txtSongName.setText(songName);
        mediaPlayer=MediaPlayer.create(getApplicationContext(),uri);
        mediaPlayer.start();

        btnpause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mediaPlayer.isPlaying())
                {
                    btnplay.setBackgroundResource(R.drawable.ic_baseline_play_arrow_24);
                    mediaPlayer.stop();
                }
                else
                {
                    btnplay.setBackgroundResource(R.drawable.pause);
                    mediaPlayer.start();

                    //TranslateAnimation moveAnim = new TranslateAnimation(-25,25,-25,25);
                    // moveAnim.setInterpolator(new AccelerateInterpolator());
                    //moveAnim.setDuration(600);
                    //moveAnim.setFillEnabled(true);
                    //moveAnim.setFillAfter(true);
                    //moveAnim.setRepeatMode(Animation.REVERSE);
                    //moveAnim.setRepeatCount(10);
                    //imageView.setAnimation(moveAnim);
                }


            }
        });






    }
}